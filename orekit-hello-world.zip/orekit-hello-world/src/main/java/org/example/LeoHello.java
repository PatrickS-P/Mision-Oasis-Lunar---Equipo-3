package org.example;

import org.hipparchus.util.FastMath;
import org.orekit.bodies.CelestialBodyFactory;
import org.orekit.data.DataContext;
import org.orekit.data.DataProvidersManager;
import org.orekit.data.DirectoryCrawler;
import org.orekit.frames.FramesFactory;
import org.orekit.orbits.KeplerianOrbit;
import org.orekit.orbits.PositionAngleType;
import org.orekit.propagation.analytical.KeplerianPropagator;
import org.orekit.time.AbsoluteDate;
import org.orekit.time.TimeScalesFactory;
import org.orekit.utils.Constants;

import java.io.File;

/**
 * Orekit Hello-World: propagación kepleriana de una órbita LEO circular.
 *
 * Condiciones iniciales (estilo ISS):
 *   a  = 6 778 km   (altitud ~400 km)
 *   e  = 0.001      (casi circular)
 *   i  = 51.6°      (inclinación ISS)
 *   Ω  = 0°, ω = 0°, M₀ = 0°
 *
 * Se propaga 1 órbita completa (~92 min) en pasos de 5 minutos
 * e imprime posición ECI en cada paso.
 */
public class LeoHello {

    public static void main(String[] args) throws Exception {

        // ── 1. Configurar datos de Orekit ──────────────────────────────────
        // Orekit necesita archivos de datos (Earth orientation, UTC-TAI, etc.)
        // Aquí usamos el jar de datos que viene en el classpath o directorio local.
        File orekitData = findOrekitData();
        DataProvidersManager manager = DataContext.getDefault().getDataProvidersManager();
        manager.addProvider(new DirectoryCrawler(orekitData));
        System.out.println("✓ Datos Orekit cargados desde: " + orekitData.getAbsolutePath());

        // ── 2. Época inicial ───────────────────────────────────────────────
        AbsoluteDate epoch = new AbsoluteDate(
            2024, 1, 1, 0, 0, 0.0,
            TimeScalesFactory.getUTC()
        );
        System.out.println("✓ Época inicial : " + epoch.toString(TimeScalesFactory.getUTC()));

        // ── 3. Parámetros de la órbita LEO ─────────────────────────────────
        double mu      = Constants.EGM96_EARTH_MU;   // 3.986e14 m³/s²
        double a       = 6_778_000.0;                // semieje mayor [m]  (~400 km alt)
        double e       = 0.001;                      // excentricidad
        double i       = FastMath.toRadians(51.6);   // inclinación [rad]
        double raan    = 0.0;                        // RAAN  [rad]
        double omega   = 0.0;                        // argumento del perigeo [rad]
        double m0      = 0.0;                        // anomalía media inicial [rad]

        KeplerianOrbit orbit = new KeplerianOrbit(
            a, e, i, omega, raan, m0,
            PositionAngleType.MEAN,
            FramesFactory.getEME2000(),
            epoch,
            mu
        );

        double T = orbit.getKeplerianPeriod();
        System.out.printf("✓ Período orbital : %.2f min%n", T / 60.0);
        System.out.println();

        // ── 4. Propagador kepleriano ───────────────────────────────────────
        KeplerianPropagator propagator = new KeplerianPropagator(orbit);

        // ── 5. Propagar 1 órbita completa en pasos de 5 min ───────────────
        System.out.printf("%-28s  %14s  %14s  %14s  %12s%n",
            "Fecha UTC", "X [km]", "Y [km]", "Z [km]", "Radio [km]");
        System.out.println("─".repeat(90));

        double step      = 300.0;           // 5 minutos en segundos
        double totalTime = T;               // 1 período completo

        for (double dt = 0; dt <= totalTime + 1; dt += step) {
            var state = propagator.propagate(epoch.shiftedBy(dt));
            var pos   = state.getPVCoordinates().getPosition();

            double x = pos.getX() / 1000.0;
            double y = pos.getY() / 1000.0;
            double z = pos.getZ() / 1000.0;
            double r = pos.getNorm() / 1000.0;

            String dateStr = state.getDate().toString(TimeScalesFactory.getUTC());
            System.out.printf("%-28s  %14.3f  %14.3f  %14.3f  %12.3f%n",
                dateStr, x, y, z, r);
        }

        System.out.println("─".repeat(90));
        System.out.println("✓ Propagación completada — cadena de herramientas Orekit OK");
    }

    /**
     * Busca el directorio de datos Orekit en ubicaciones comunes.
     * En producción apunta a un orekit-data descargado o al jar de datos.
     */
    private static File findOrekitData() {
        // 1. Variable de entorno
        String env = System.getenv("OREKIT_DATA_DIR");
        if (env != null) {
            File f = new File(env);
            if (f.isDirectory()) return f;
        }

        // 2. Directorio local ./orekit-data
        File local = new File("orekit-data");
        if (local.isDirectory()) return local;

        // 3. Fallback: extraer datos del classpath (jar de datos)
        //    Para este hello-world, creamos datos mínimos en /tmp/orekit-data
        File tmp = new File(System.getProperty("java.io.tmpdir"), "orekit-data");
        tmp.mkdirs();
        return tmp;
    }
}
